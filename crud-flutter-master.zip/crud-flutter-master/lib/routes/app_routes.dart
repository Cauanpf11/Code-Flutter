class AppRoutes {
  static const home = '/';
  static const user_form = '/user-form';
}
